package org.example;

public class Main {

    private Nodo head;
    private Nodo tail;

    public Main() {
        this.head = null;
        this.tail = null;
    }

  
    public void insertAtEnd(int data) {
        Nodo newNode = new Nodo(data);
        if (tail == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
    }


    public void insertAtBeginning(int data) {
        Nodo newNode = new Nodo(data);
        if (head == null) {
            head = tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }

    // Eliminar un nodo con un valor específico
    public boolean delete(int data) {
        Nodo current = head;
        while (current != null) {
            if (current.data == data) {
                if (current == head) {
                    head = current.next;
                    if (head != null)
                        head.prev = null;
                } else if (current == tail) {
                    tail = current.prev;
                    if (tail != null)
                        tail.next = null;
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }
                return true;
            }
            current = current.next;
        }
        return false;
    }

    // Buscar un nodo con un valor específico
    public boolean search(int data) {
        Nodo current = head;
        while (current != null) {
            if (current.data == data) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    // Mostrar la lista de adelante hacia atrás
    public void displayForward() {
        Nodo current = head;
        while (current != null) {
            System.out.print(current.data + " <-> ");
            current = current.next;
        }
        System.out.println("null");
    }

    // Mostrar la lista de atrás hacia adelante
    public void displayBackward() {
        Nodo current = tail;
        while (current != null) {
            System.out.print(current.data + " <-> ");
            current = current.prev;
        }
        System.out.println("null");
    }

    // Contar el número de nodos en la lista
    public int countNodes() {
        int count = 0;
        Nodo current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    // Insertar un nodo después de un valor específico
    public boolean insertAfter(int afterData, int newData) {
        Nodo current = head;
        while (current != null) {
            if (current.data == afterData) {
                Nodo newNode = new Nodo(newData);
                newNode.next = current.next;
                newNode.prev = current;
                if (current.next != null) {
                    current.next.prev = newNode;
                } else {
                    tail = newNode;
                }
                current.next = newNode;
                return true;
            }
            current = current.next;
        }
        return false;  // No se encontró el nodo con el valor 'afterData'
    }


    public void reverse() {
        Nodo current = head;
        Nodo temp = null;
        while (current != null) {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev;
        }
        if (temp != null) {
            head = temp.prev;
        }
    }

    // Método main para ejecutar el programa
    public static void main(String[] args) {
        // Crear una instancia de la lista doblemente enlazada
        Main list = new Main();

        // Insertar elementos al final
        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);

        // Mostrar la lista de adelante hacia atrás
        System.out.println("Lista de adelante hacia atrás:");
        list.displayForward();

        // Mostrar la lista de atrás hacia adelante
        System.out.println("Lista de atrás hacia adelante:");
        list.displayBackward();

        // Eliminar un nodo con un valor específico
        System.out.println("Eliminar 20 de la lista:");
        list.delete(20);

        // Mostrar la lista después de eliminar un nodo
        System.out.println("Lista después de eliminar 20:");
        list.displayForward();

        // Contar los nodos
        System.out.println("Número de nodos: " + list.countNodes());

        // Revertir la lista
        System.out.println("Lista después de revertir:");
        list.reverse();
        list.displayForward();
    }
}