package org.example;

public class Nodo {
    int data;  // Valor almacenado en el nodo
    Nodo prev; // Referencia al nodo anterior
    Nodo next; // Referencia al siguiente nodo


    public Nodo(int data) {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}

